package cgu.im.helloworld01;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import cgu.im.helloworld01.domain.Car;
import cgu.im.helloworld01.domain.CarRepository;
import cgu.im.helloworld01.domain.Owner;
import cgu.im.helloworld01.domain.OwnerRepository;

@SpringBootApplication
public class Helloworld01Application implements CommandLineRunner {
	
	CarRepository 	repository;
	OwnerRepository orepository;
	
	public Helloworld01Application(CarRepository repository,
								   OwnerRepository orepository) {
		this.repository = repository;
		this.orepository = orepository;
	}
	
	private static final Logger logger =
            LoggerFactory.getLogger(
                    Helloworld01Application.class
            );

	public static void main(String[] args) {
		SpringApplication.run(Helloworld01Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Owner owner1 = new Owner("John" , "Johnson");
		Owner owner2 = new Owner("Mary" , "Robinson");
		orepository.save(owner1);
		orepository.save(owner2);
		
		repository.save(new Car("Ford", "Mustang", "Red","ADA-1121", 2023, 59000, owner1));
		repository.save(new Car("Nissan", "Leaf","White", "SSJ-3002", 2020, 29000, owner2));
		repository.save(new Car("Toyota", "Prius", "Silver","KKO-0212", 2022, 39000, owner2));
		repository.save(new Car("Nissan", "Tiida", "Red","ADA-3212", 2022, 19000, owner1));
		repository.save(new Car("Toyota", "Altis","Silver", "0212-DD", 2023, 21000, owner1));

		
		// Fetch all cars and log to console
		for (Car car : repository.findAll()) {
			logger.info("brand: {}, model: {}",
			car.getBrand(), car.getModel());
		}
		
		// 取得所有車主的所有汽車資料     // 先印出車主編號、姓氏   //   然後逐行印出他名下汽車的車號
		for (Owner owner : orepository.findAllWithCars()) {	    	       
		      System.out.printf("owner#: %s last_name: %s\n", 
		      owner.getOwnerid(), owner.getLastname());	            	            
		      List<Car> cars = owner.getCars();
			            
		      if(cars == null) {
			System.out.println(owner.getLastname() + "has no car"); 
		      }
		      else {	            	
		        	for(Car cc: cars) {
			      System.out.println(cc.getRegistrationNumber());
			}		            
		       }
		}
		
		Owner owner3 = new Owner("Ichiro" , "Suzuki");
		orepository.save(owner3);
		
		//取得所有車主的所有汽車資料	(沒有汽車的車主也要印出來
		// 先印出車主編號、姓氏 //   然後逐行印出他名下汽車的車號
		for (Owner owner : orepository.findAllOwnersWithCars()) {	    	 
		       System.out.printf("owner#: %s last_name: %s\n", 
		       owner.getOwnerid(), owner.getLastname());
			            	            
		       List<Car> cars = owner.getCars();
		       if(cars.size() == 0) {
		        	System.out.println(owner.getLastname() + " has no car"); 
		        }
		        else {	            	
		             for(Car cc: cars) {
		         	     System.out.println(cc.getRegistrationNumber());
		             }		            
		        }
		}
		
		 repository.save(new Car("Tesla", "Model_X", "Blue",
	        		"TTT-8888", 2024, 45000, null));

		 
		// 取得所有汽車並印出車廠、車款、車號、車主姓氏；如無車主請印"無車主"
	     
		 int i = 1;
		 for (Car c : repository.findAllCarsWithOwnerLastNames()) {	    	 
		  	System.out.printf("%d %8s %8s %10s %10s\n", i++, 
		 		  c.getBrand(), c.getModel(), c.getRegistrationNumber(),
		 		  c.getOwner() != null?c.getOwner().getLastname():"無車主");	    	
		 }

		// JPQL印出所有非銀色汽車資料及其車主姓氏，即使尚未售出也要列出來
		   System.out.println("所有非銀色汽車資料及其車主姓氏，即使尚未售出也要列出來");
		   int j = 1;
		   List<Car> cars1 = repository.findNonSilverCarsWithOwner();
		   System.out.println("#304:"+cars1.size());
		   for (Car c : cars1) {		    	 
		       	  System.out.printf("%d %8s %8s %10s %10s\n", j++, 
		           			  c.getBrand(), c.getModel(), c.getRegistrationNumber(),
		           			  c.getOwner() != null?c.getOwner().getLastname():"無車主");	    	     	    		 
		    }

		   // JPQL印出John的所有非銀色汽車資料
		   int k = 1;
		   List<Car> cars2 = repository.findJohnNonSilverCars();
		   System.out.println("John的所有非銀色汽車資料有"+cars2.size()+"台");
		   for (Car c : cars2) { 
		   System.out.printf("%d %8s %8s %10s %10s\n", k++, 
		   c.getBrand(), c.getModel(), c.getRegistrationNumber(),
		   	     c.getOwner().getLastname()); 
		   }
		   
	   	// JPQL印出某位車主的所有非銀色汽車資料
		   System.out.println("Robinson的所有非銀色汽車資料");
		   int x = 1;
		   List<Car> cars3 = repository.findSomeoneNonSilverCars("Robinson");	     
		   for (Car c : cars3) {		    	 
		              	  System.out.printf("%d %8s %8s %10s %10s\n", x++, 
		              			  c.getBrand(), c.getModel(), c.getRegistrationNumber(),
		              			  c.getOwner().getLastname());	    	     	    
		   }
		   
		   // JPQL印出某位車主的所有非銀色汽車資料
		   System.out.println("Robinson的所有非銀色汽車資料");
		   int y = 1;
		   List<Car> cars4 = repository.findSomeoneNonSilverCars2("Robinson");	     
		   for (Car c : cars4) {		    	 
		              	  System.out.printf("%d %8s %8s %10s %10s\n", y++, 
		              			  c.getBrand(), c.getModel(), c.getRegistrationNumber(),
		              			  c.getOwner().getLastname());	    	     	    	 
		   }






		
	}
}
