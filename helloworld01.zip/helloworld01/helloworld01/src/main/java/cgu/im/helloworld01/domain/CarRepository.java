package cgu.im.helloworld01.domain;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface CarRepository extends CrudRepository<Car, Long> {
	
	// Fetch all cars and sort them by model_year
    // List<Car> findByModelYearOrderByModelYear(int year);

    //Fetch all cars and sort them by model_year
    List<Car> findOrderByModelYear(int year);
    
    //Fetch all cars and sort them by model_year
    List<Car> findAllOrderByModelYear(int year);
    
    //Fetch all cars and sort them by model_year
    //List<Car> findByOrderByModelYear(int year);
    
    //
    List<Car> findByColor(@Param("color") String color);
    
    // Delete a car c
    void delete(Car c);
    
    // Fetch cars based on their colors and sort them by model year
    List<Car> findByColorOrderByModelYear(String color);
    
    // Fetch all cars except those produced in the year of excluded
    List<Car> findByModelYearNot(int excluded);    
    
    // Fetch cars by brand using SQL
    @Query("select c from Car c where c.brand like %?1")
    List<Car> findByBrandEndsWith(String brand);
    
    // Fetch cars by brand using SQL
    @Query("select c from Car c where c.brand like %?1%")
    List<Car> findByBrandContaining(String brand);
    
    // Fetch cars by brand using SQL
    @Query("select c from Car c where c.brand like '______'")
    List<Car> findByBrandSixLetter();

    // JPQL印出所有汽車資料及其車主姓氏，即使尚未售出也要列出來
    @Query("SELECT c FROM Car c LEFT JOIN FETCH c.owner")
    List<Car> findAllCarsWithOwnerLastNames(); 

    @Query("SELECT c FROM Car c LEFT JOIN c.owner o WHERE c.color <> 'Silver'")
    List<Car> findNonSilverCarsWithOwner(); 

    @Query("SELECT c FROM Car c LEFT JOIN c.owner o WHERE c.color <> 'Silver' AND o.lastname = 'John'")
    List<Car> findJohnNonSilverCars();
    
    @Query("SELECT c FROM Car c LEFT JOIN c.owner o WHERE c.color <> 'Silver' AND o.lastname = ?1")
    List<Car> findSomeoneNonSilverCars(String owner);
    
    // JPQL印出某位車主的所有非銀色汽車資料 (名稱參數)
    @Query("SELECT c FROM Car c LEFT JOIN c.owner o WHERE c.color <> 'Silver' AND o.firstname = :owner")
    List<Car> findSomeoneNonSilverCars2(@Param("owner") String owner);








}
