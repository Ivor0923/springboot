package cgu.im.helloworld01.domain;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface CarRepository extends CrudRepository<Car, Long> {
	
	// Fetch all cars and sort them by model_year
    // List<Car> findByModelYearOrderByModelYear(int year);

    //Fetch all cars and sort them by model_year
    List<Car> findOrderByModelYear(int year);
    
    //Fetch all cars and sort them by model_year
    List<Car> findAllOrderByModelYear(int year);
    
    //Fetch all cars and sort them by model_year
    //List<Car> findByOrderByModelYear(int year);
    
    //
    List<Car> findByColor(String color);
    
    // Delete a car c
    void delete(Car c);
    
    // Fetch cars based on their colors and sort them by model year
    List<Car> findByColorOrderByModelYear(String color);
    
    // Fetch cars by brand using JPQL
    @Query("select c from Car c where c.brand = ?1")
    List<Car> findByBrand1(String brand);
    
    // Fetch cars by brand using SQL
    @Query("select c from Car c where c.brand like %?1")
    List<Car> findByBrandEndsWith(String brand);
    
    // Fetch cars by brand using SQL
    @Query("select c from Car c where c.brand like '______'")
    List<Car> findByBrandSixLetter();
    
    // JPQL取得所有車子的平均價格
    @Query("SELECT AVG(c.price) FROM Car c")
    double findAvgCarPrice(); 
    
    // JPQL找出最便宜的車價 in CarRepository interface  
    @Query("SELECT MIN(c.price) FROM Car c")
    double findMinCarPrice(); 
    
    // JPQL取得所有車子的平均價格    in CarRepository interface
    @Query("SELECT COUNT(c) FROM Car c")
    int findCarNumber(); 
    
    // JPQL取得所有車子的平均價格    in CarRepository interface
    @Query("SELECT COUNT(DISTINCT c.brand) FROM Car c")
    int findCarBrandNumber(); 
    
    // JPQL取得所有車子的平均價格    in CarRepository interface
    @Query("SELECT SUM(c.price)*0.12 FROM Car c")
    int findPriceTax(); 

    //JPQL查詢2022年之後出廠的車輛
    @Query("SELECT c FROM Car c WHERE c.modelYear >= 2022")
    List<Car> findNewCars();

    //JPQL查詢2022年之後出廠的車輛
    @Query("SELECT c FROM Car c WHERE c.registrationNumber like '____-%'")
    List<Car> findCarByRegistrationNumberFifthLetter();
    
    //JPQL查詢2022年之後出廠的車輛
    @Query("SELECT c FROM Car c WHERE c.registrationNumber like '%2%2%'")
    List<Car> findCarByRegistrationNumberContaining2AtLeastTwice();

    String q1 = "SELECT c FROM Car c ";
    String q2 = "WHERE c.registrationNumber LIKE '___-1%' "+ "OR ";
    String q3 = "c.registrationNumber LIKE '___-2%' "+ "OR ";
    String q4 = "c.registrationNumber LIKE '___-3%'";
        
    @Query(value=q1+q2+q3+q4)
    List<Car> findCarByNewRegistrationNumberSecondPartBeginWith1Or2Or3();

    //JPQL查詢車廠為Toyota者
    @Query("SELECT c FROM Car c WHERE c.brand LIKE 'Toyota'")
    List<Car> findToyota();





    









}
