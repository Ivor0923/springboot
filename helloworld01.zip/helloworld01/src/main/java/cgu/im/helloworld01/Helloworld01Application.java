package cgu.im.helloworld01;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import cgu.im.helloworld01.domain.Car;
import cgu.im.helloworld01.domain.CarRepository;
import cgu.im.helloworld01.domain.Owner;
import cgu.im.helloworld01.domain.OwnerRepository;

@SpringBootApplication
public class Helloworld01Application implements CommandLineRunner {
	
	CarRepository 	repository;
	OwnerRepository orepository;
	
	public Helloworld01Application(CarRepository repository,
								   OwnerRepository orepository) {
		this.repository = repository;
		this.orepository = orepository;
	}
	
	private static final Logger logger =
            LoggerFactory.getLogger(
                    Helloworld01Application.class
            );

	public static void main(String[] args) {
		SpringApplication.run(Helloworld01Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Owner owner1 = new Owner("John" , "Johnson");
		Owner owner2 = new Owner("Mary" , "Robinson");
		orepository.save(owner1);
		orepository.save(owner2);
		
		repository.save(new Car("Ford", "Mustang", "Red","ADA-1121", 2023, 59000, owner1));
		repository.save(new Car("Nissan", "Leaf","White", "SSJ-3002", 2020, 29000, owner1));
		repository.save(new Car("Toyota", "Prius", "Silver","KKO-0212", 2022, 39000, owner2));
		repository.save(new Car("Nissan", "Tiida", "White","SSJ-3003", 2021, 17000, owner2));
		repository.save(new Car("Toyota", "Altis","Silver", "KKO-0213", 2024, 29000, owner2));


		
		// Fetch all cars and log to console
		for (Car car : repository.findAll()) {
			logger.info("brand: {}, model: {}",
			car.getBrand(), car.getModel());
		}
		
		System.out.println("---JPQL: 找出Ford車-------");	    
		for (Car car : repository.findByBrand1("Ford")) {	    	 
			logger.info("brand: {}, car#: {}, year: {}",
			car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
		}
		
		System.out.println("---JPQL: 找出廠牌是a結尾的汽車-");	    
		for (Car car : repository.findByBrandEndsWith("a")) {	    	 
			logger.info("brand: {}, car#: {}, year: {}",
			car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
		}
		
		System.out.println("---JPQL: 找出六字元廠牌的汽車---");	 
		for (Car car : repository.findByBrandSixLetter()) {	    	 
			logger.info("brand: {}, car#: {}, year: {}",
			car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
		}
		
		// 取得所有車子的平均價格
		System.out.println("JPQL取得所有車子的平均價格: "+
		    		     repository.findAvgCarPrice());
            
		// 取得汽車最低價
		System.out.println("JPQL找出最便宜的車價: "+
			    		 repository.findMinCarPrice());

		// 取得所有車子的數量
		System.out.println("JPQL求得所有汽車的數量: "+
			    		 repository.findCarNumber());

		//計算車廠數量
		System.out.println("JPQL計算不同車廠的數量  : "+
			    		 repository.findCarBrandNumber());
		
		// In run() of HelloworldApplication class
	     System.out.println("JPQL計算所有車價總和的12%  : "+
	    		 repository.findPriceTax());
	     
	     System.out.println("JPQL查詢2022年之後出廠車輛的車廠、車號、出廠年份: ");
	     
	     for (Car car : repository.findNewCars()) {	    	 
	     	      logger.info("brand: {}, car#: {}, year: {}",
	     	      car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
	     }

	     repository.save(new Car("Toyota", "Mustang", "Red","0212-DD", 2023, 59000, owner1));

	     System.out.println("JPQL查詢車輛廠牌是舊式車牌者 ");
	     
	     for (Car car : repository.findCarByRegistrationNumberFifthLetter()) {	    	 
	            logger.info("brand: {}, car#: {}, year: {}",
	                     car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
	     }
	     
	     System.out.println("JPQL查詢車號至少包含兩個2者 ");
	     
	     for (Car car : repository.findCarByRegistrationNumberContaining2AtLeastTwice()) {	     
	                 logger.info("brand: {}, car#: {}, year: {}",
	                     car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
	     }
	     
	     System.out.println("JPQL查詢新式車號後四碼為1,2,3開頭者 ");
	     
	     for (Car car : repository.findCarByNewRegistrationNumberSecondPartBeginWith1Or2Or3()) {	     
	            logger.info("brand: {}, car#: {}, year: {}",
	                     car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
	     }
	     
	     System.out.println("JPQL查詢車廠為Toyota者 ");
	     
	     for (Car car : repository.findToyota()) {	     
	            logger.info("brand: {}, car#: {}, year: {}",
	                     car.getBrand(), car.getRegistrationNumber(), car.getModelYear());
	     }








		
	}
	
}

