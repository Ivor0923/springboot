package cgu.im.helloworld01.domain;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

//@RepositoryRestResource(path="carowners")
public interface OwnerRepository extends CrudRepository<Owner, Long> {

	// JPQL取得所有車主的所有汽車資料
	@Query("SELECT o FROM Owner o JOIN o.cars")
	List<Owner> findAllWithCars(); 
	
	// JPQL取得所有車主的所有汽車資料，即使是沒有汽車的車主也要列出來
	@Query("SELECT o FROM Owner o LEFT JOIN o.cars")
	List<Owner> findAllOwnersWithCars(); 

	
}
